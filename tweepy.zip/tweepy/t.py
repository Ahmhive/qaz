import tweepy

consumer_keys = ('BCcsklCjIRHal0VMmxdcLkSdP','zUOGwsP0JNFqbvLxNEg2YxkUg','Kqxs85C2TLheOV5ysxsrzNmYk','UBvqfyVtSB2SWF066KhBLXbMm')
consumer_secrets = ('3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J','q4VUKbF3CYxoIH9B0bOnKg4Rkskcp5k7yaJNaHOv8ThVvExs9t','WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L','qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h')
access_tokens = ('3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J','q4VUKbF3CYxoIH9B0bOnKg4Rkskcp5k7yaJNaHOv8ThVvExs9t','WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L','qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h')
access_token_secrets = ('3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J','q4VUKbF3CYxoIH9B0bOnKg4Rkskcp5k7yaJNaHOv8ThVvExs9t','WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L','qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h')

for A in consumer_keys:
    consumer_key = A
    consumer_secret = A
    access_token = A
    access_token_secret = A
    print (A)
#consumer_key = "BCcsklCjIRHal0VMmxdcLkSdP"
#consumer_secret = "3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J"
#access_token = "1590007885852991488-tF6IXmUt2kRhdyvgJErHGUQOstT6gt"
#access_token_secret = "judMLyoARe3c1KLvMYDz9j7qtGaRT4l6sVxtJVt8lcIas"

client = tweepy.Client(
    consumer_key=consumer_key, consumer_secret=consumer_secret,
    access_token=access_token, access_token_secret=access_token_secret
)


response = client.create_tweet(
    text="This Tweet was Tweeted using Tweepy and Twitter API v2!"
)
print(f"https://twitter.com/user/status/{response.data['id']}")
