from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
from random import randint
import tweepy
import os
import zipfile
from imap_tools import MailBox, AND
from anticaptchaofficial.funcaptchaproxyless import *
from urllib.parse import quote
import csv
import secrets
import string
import pyperclip


for index in range(80, 100):
    try:
        with open('dataaccdev.csv') as csvfile:
            csvstring = csvfile.read() + '\n'
            lines = csvstring.splitlines()
            reader = csv.reader(lines)
            csvdata = list(reader)
            print (csvdata[index])
            #proxyuser = csvdata[index][0]
            #proxypass = csvdata[index][1]
            username = csvdata[index][2]
            password = csvdata[index][3]
            phone = csvdata[index][4]
            email= csvdata[index][5]
            emailpass = csvdata[index][6]
            #access_token = csvdata[index][6]
            #access_token_secret = csvdata[index][7]
            #consumer_key = csvdata[index][8]
            #consumer_secret = csvdata[index][9]
            
        PROXY_HOST = 'zproxy.lum-superproxy.io'  # rotating proxy or host
        PROXY_PORT = 22225 # port
        PROXY_USER = "brd-customer-hl_b4776d43-zone-b1" # username
        PROXY_PASS = "sgyem2ztpbsp" # password


        manifest_json = """
        {
            "version": "1.0.0",
            "manifest_version": 2,
            "name": "Chrome Proxy",
            "permissions": [
                "proxy",
                "tabs",
                "unlimitedStorage",
                "storage",
                "<all_urls>",
                "webRequest",
                "webRequestBlocking"
            ],
            "background": {
                "scripts": ["background.js"]
            },
            "minimum_chrome_version":"22.0.0"
        }
        """

        background_js = """
        var config = {
                mode: "fixed_servers",
                rules: {
                singleProxy: {
                    scheme: "http",
                    host: "%s",
                    port: parseInt(%s)
                },
                bypassList: ["localhost"]
                }
            };

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "%s",
                    password: "%s"
                }
            };
        }

        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)

        
        pluginfile = 'proxy_auth_plugin.zip'

        with zipfile.ZipFile(pluginfile, 'w') as zp:
            zp.writestr("manifest.json", manifest_json)
            zp.writestr("background.js", background_js)


        options = webdriver.ChromeOptions()
        #options.add_argument('--headless=chrome')
        options.add_extension(pluginfile)
        options.add_argument('--window-size=1920,1200')  
        options.add_argument('--ignore-certificate-errors')  


        #proxy = ("http://brd-customer-hl_b4776d43-zone-2:d2gzikkwg5id@zproxy.lum-superproxy.io:22225")
        #os.environ['http_proxy'] = proxy 
        #os.environ['HTTP_PROXY'] = proxy
        #os.environ['https_proxy'] = proxy
        #os.environ['HTTPS_PROXY'] = proxy


        #urlauth = oauth1_user_handler.get_authorization_url(signin_with_twitter=True)
        #print (urlauth)
        
        driver = webdriver.Chrome(executable_path=CM().install(), options=options)
        actions = ActionChains(driver)
        actions2 = ActionChains(driver)
        actions3 = ActionChains(driver)


        #driver.get(urlauth)
        #driver.get("https://www.whatismyip.com/")
        #iptext = (By.XPATH, '/html/body/div[2]/div/div[1]/div/div/main/article/div[1]/section/div/h2[1]/span/a').text
        #print(iptext)

        
        driver.get("https://twitter.com/login")
        
        
        # username 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[5]/label/div/div[2]/div/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[5]/label/div/div[2]/div/input'))).send_keys(username)

        # click next
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[6]/div'))).click() 

        # pass
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[3]/div/label/div/div[2]/div[1]/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[3]/div/label/div/div[2]/div[1]/input'))).send_keys(password)

        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div[1]/div/div/div/div'))).click() 
        try:
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input'))).click() 
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input'))).send_keys(phone)

            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div/div'))).click() 
        except:
            print('no email/phone')
        sleep(5)
        """
        driver.get("https://twitter.com/i/flow/add_email")
        #(By.XPATH, '').click() 
        #(By.XPATH, '').send_keys(phone)
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[2]/div/label/div/div[2]/div[1]/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[2]/div/label/div/div[2]/div[1]/input'))).send_keys(password)
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div'))).click() 
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div/label/div/div[2]/div/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div/label/div/div[2]/div/input'))).send_keys(email)
        sleep(5)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div/div'))).click()
        sleep(10)

        with MailBox('imap-mail.outlook.com').login(email, emailpass) as mailbox:
            for msg in mailbox.fetch():
                try:
                    codeend = msg.subject.index(" is your Twitter verification code")
                    verifycode = msg.subject[0:codeend]
                    print(verifycode)
                except:
                    donothing = True    

        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input'))).send_keys(verifycode)
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div/div'))).click() 
        sleep(7)

        
        driver.get("https://developer.twitter.com/en/portal/dashboard")
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[3]/fieldset'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[3]/fieldset/select/option[233]'))).click()
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[4]/fieldset'))).click() 
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[4]/fieldset/select/option[6]'))).click() 
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[5]/fieldset'))).click() 
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[5]/fieldset/select/option[3]'))).click() 

        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div/div[2]/div/div[2]/ul/li[2]/button'))).click() 
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[7]/button'))).click() 
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[1]/div[1]/span[1]'))).click() 
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div[2]/button[2]/span'))).click() 
        

        sleep(10)
        with MailBox('imap-mail.outlook.com').login(email, emailpass) as mailbox:
            for msg in mailbox.fetch():
                try:
                    urlstart = msg.html.index("https://developer.twitter.com/en/portal/account/")
                    urlend = msg.html.index("/verify") + 7
                    emailpaste = msg.html
                    verifylink = emailpaste[urlstart:urlend]
                    print(verifylink)
                except:
                    donothing = True

        driver.get(verifylink)
        
        #driver.get('https://developer.twitter.com/en/portal/register/welcome')

        
        alphabet = string.ascii_letters
        randombit = ''.join(secrets.choice(alphabet) for i in range(6))
        appname = f'TweetHelper {randombit}'
        oobtext = 'https://oob'
        websitetext = f'http://tweet{randombit}.com'
        
        #appname 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div/div/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/div/div/input'))).send_keys(appname)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/form/button'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[2]/div[1]/a/button'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[2]/div/div/button[2]/span'))).click() 
        
        driver.get('https://developer.twitter.com/en/portal/')
        #setting button /html/body/div[1]/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div/div/div[2]/div[2]/div/div/div/div[2]/a[1]/div/div/span
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div/div/div[2]/div[2]/div/div/div/div[2]/a[1]/div/div/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div[4]/div/div/div/button/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[3]/form/div/div[3]/div[1]/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[4]/form/div/div[2]/div[1]/span'))).click() 
        driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
        #/html/body/div[1]/div/div/div[2]/div/div[2]
        
        #https://oob
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[5]/form/div[1]/div[2]/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[5]/form/div[1]/div[2]/input'))).send_keys(oobtext)
        #website 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[5]/form/div[2]/input'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[5]/form/div[2]/input'))).send_keys(websitetext)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div[6]/button[2]/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[3]/div/div/div[3]/button[2]/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div/div[1]/div/div/div/div[3]/button/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[2]/div/button/span'))).click() 
        
        """
        driver.get('https://developer.twitter.com/en/portal/')
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div/div/div[2]/div[2]/div/div/div/div[2]/a[1]/div/div/span'))).click() 
        
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[1]/nav/ul/li[2]/button'))).click() 
        #api
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div[2]/div/button'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[3]/button[2]/span'))).click() 
        apikey = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[2]/div[2]/p'))).text
        apisecret = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[3]/div[2]/p'))).text
        print(apikey, apisecret)
        sleep(3)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[2]/div/button'))).click()
        #bearer
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[2]/div[1]/button/span'))).click() 
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[3]/button[2]/span'))).click()
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[2]/div[2]/button'))).click()
        #bearer = pyperclip.paste()
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[2]/div/button/span'))).click()
        #acess
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div/button/span'))).click() 
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[3]/button[2]/span'))).click()
        sleep(2)
        access_token = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[2]/div[2]/p'))).text
        sleep(2)
        access_token_secret = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[3]/div[2]/p'))).text
        sleep(2)
        print(access_token,access_token_secret)
        sleep(4)
        driver.find_element_by_xpath('/html/body/div[5]/div/div/div[2]/div/button').click() 

        #client
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div/div[2]/div/div[2]/ul/li[2]/button'))).click()
        client = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/span'))).text
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[5]/div[2]/div/button/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[3]/button[2]/span'))).click()
        clientsecret = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[2]/div[2]/p'))).text
        print(client,clientsecret)
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[2]/div/button/span'))).click()

        sleep(5)

        """
        ##when makeing
        driver.get('https://developer.twitter.com/en/portal/')
        
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div/div/div[2]/div[2]/div/div/div/div[2]/a[1]/div/div/span'))).click() 
        
        ## when making
        sleep(5)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[1]/nav/ul/li[2]/button'))).click() 
        #api
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div[2]/div/button'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[3]/div/div/div[3]/button[2]/span'))).click() 
        apikey = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[1]/div[2]/div[2]/div[2]/p'))).text
        apisecret = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[1]/div[2]/div[3]/div[2]/p'))).text
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[2]/div/button/span'))).click()
        #bearer
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[2]/div[1]/button/span'))).click() 
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[3]/button[2]/span'))).click()
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[1]/div[2]/div[2]/div[2]/button'))).click()
        #bearer = pyperclip.paste()
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div[2]/div/button/span'))).click()
        #acess /html/body/div[4]/div/div/div[1]/div[2]/div[3]/div[2]/p
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div/button/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[3]/div/div/div[3]/button[2]/span'))).click()
        access_token = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[1]/div[2]/div[2]/div[2]/p'))).text
        access_token_secret = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[1]/div[2]/div[3]/div[2]/p'))).text
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[2]/div/button/span'))).click()
        #client /html/body/div[4]/div/div/div[1]/div[2]/div[3]/div[2]/p
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div/div[2]/div/div[2]/ul/li[2]/button'))).click()
        client = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/span'))).text
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div[1]/div/div[5]/div[2]/div/button/span'))).click() 
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[3]/div/div/div[3]/button[2]/span'))).click()

        clientsecret = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[1]/div[2]/div[2]/div[2]/p'))).text
        sleep(2)
        WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div/div[2]/div/button/span'))).click()
        """
        sleep(5)
        
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, ''))).click()  /html/body/div[5]/div/div/div[2]/div/button/span
        #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, ''))).send_keys(phone)

        file_1= '/home/user/tweepy/1devacc.txt'
        try:
            with open(file_1, 'a+') as filehandle:
                filehandle.write('%s:%s:%s:%s:%s:%s:%s:%s:%s:%s:%s:\n' % (username, password, email, emailpass, phone, apikey, apisecret, access_token, access_token_secret, client, clientsecret))
        except:
            print('error')
        
        sleep(5)
        driver.close() 
    except:
        print(f'error{username}')
        driver.close() 
#token = driver.execute_script('location.reload();var i=document.createElement("iframe");document.body.appendChild(i);return i.contentWindow.localStorage.token').strip('"') # Get the token

sleep(5)

print(f'fucking done bitch!')
