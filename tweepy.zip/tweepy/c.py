import tweepy


consumer_keys = ('BCcsklCjIRHal0VMmxdcLkSdP','zUOGwsP0JNFqbvLxNEg2YxkUg','Kqxs85C2TLheOV5ysxsrzNmYk','UBvqfyVtSB2SWF066KhBLXbMm')
consumer_secrets = ('3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J','q4VUKbF3CYxoIH9B0bOnKg4Rkskcp5k7yaJNaHOv8ThVvExs9t','WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L','qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h')
access_tokens = ('1590007885852991488-tF6IXmUt2kRhdyvgJErHGUQOstT6gt','1587510868979458049-BJxxeie4xsuHdjNo70BddQ5KWwMsEh','1587519258682163203-6oFLTEKwXZkUFdCkJgaSR6SK47bbmG','1587512174506811395-ueRr54VZziu8duuIGN8oN8iPwml8Sm')
access_token_secrets = ('judMLyoARe3c1KLvMYDz9j7qtGaRT4l6sVxtJVt8lcIas','JKLTAhf4JCsos91VKulRyrpgiEnN6OHsJ67ZlxDp5IXQF','aUS2x6Qy0N8XHSF7fbL7vnJruyLnSexkULwFV5SXmLSeU','J9nb8pbs8brrGfhUCq0QR7jN3UlBcRCN0puFsEFJBEqCh')

for index in range(4):
    consumer_key = consumer_keys[index]
    consumer_secret = consumer_secrets[index]
    access_token = access_tokens[index]
    access_token_secret = access_token_secrets[index]
    print (consumer_key,consumer_secret,access_token,access_token_secret)
#consumer_key = "BCcsklCjIRHal0VMmxdcLkSdP"
#consumer_secret = "3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J"
#access_token = "1590007885852991488-tF6IXmUt2kRhdyvgJErHGUQOstT6gt"
#access_token_secret = "judMLyoARe3c1KLvMYDz9j7qtGaRT4l6sVxtJVt8lcIas"

client = tweepy.Client(
    consumer_key=consumer_key, consumer_secret=consumer_secret,
    access_token=access_token, access_token_secret=access_token_secret
)


response = client.create_tweet(
    text="This Tweet was Tweeted using Tweepy and Twitter API v2!"
)
print(f"https://twitter.com/user/status/{response.data['id']}")
