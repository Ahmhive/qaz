from imap_tools import MailBox, AND

# Get date, subject and body len of all emails from INBOX folder

with MailBox('imap-mail.outlook.com').login('kesshivesof@hotmail.com', 'y4Lsba02ppw') as mailbox:
    for msg in mailbox.fetch():
        try:
            codeend = msg.subject.index(" is your Twitter verification code")
            verifycode = msg.subject[0:codeend]
            print(verifycode)
        except:
            donothing = True
        try:
            urlstart = msg.html.index("https://developer.twitter.com/en/portal/account/")
            urlend = msg.html.index("/verify") + 7
            emailpaste = msg.html
            verifylink = emailpaste[urlstart:urlend]
            print(verifylink)
        except:
            donothing = True

