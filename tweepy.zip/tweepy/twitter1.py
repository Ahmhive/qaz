from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
import tweepy
import os
import zipfile


proxy_users = (
    "brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-17")
proxy_passes = (
    "vgl6bkabha4b","vgl6bkabha4b","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","r2o4d9d48qcc")
usernames = (
        "Charles52852626","RolandE20606659","KeatsRose1","PalmerValentin6","GeorgeJamie5","WolfMark18","HarrisonJudy4","JuddAudrey1","HansomCamille1","MarjoryMegan1")
passwords = (
    "k8r2q9g.75uc","x9ojffi.2j8r","29tdgnb%re1t","v86djal%r873","","916uvbg$ep2c","97wtcaa$tut0","t00m2io@1paf","m3r8gyh.bfaq","58yz299%ogt2","82o5oz4!ijw2")
emails = (
    "ajcsnfvjap@outlook.com","yxttth@outlook.com","vahvbhgcdkc@outlook.com","wqudspvh@outlook.com","kxyenc@outlook.com","fxcert@outlook.com","thnnmydb@outlook.com","crrjna@outlook.com","dpdvjsmcx@outlook.com","pcjmgpymdgv@outlook.com")
consumer_keys = (
    "UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u")
consumer_secrets = (
    "qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS")
proxies = (
    "http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225")



for index in range(10):
  try:
    PROXY_HOST = 'zproxy.lum-superproxy.io'  # rotating proxy or host
    PROXY_PORT = 22225 # port
    PROXY_USER = proxy_users[index] # username
    PROXY_PASS = proxy_passes[index] # password


    manifest_json = """
    {
        "version": "1.0.0",
        "manifest_version": 2,
        "name": "Chrome Proxy",
        "permissions": [
            "proxy",
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version":"22.0.0"
    }
    """

    background_js = """
    var config = {
            mode: "fixed_servers",
            rules: {
            singleProxy: {
                scheme: "http",
                host: "%s",
                port: parseInt(%s)
            },
            bypassList: ["localhost"]
            }
        };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "%s",
                password: "%s"
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)


    pluginfile = 'proxy_auth_plugin.zip'

    with zipfile.ZipFile(pluginfile, 'w') as zp:
        zp.writestr("manifest.json", manifest_json)
        zp.writestr("background.js", background_js)
    options = webdriver.ChromeOptions()
    options.add_extension(pluginfile)

    consumer_key = ("UBvqfyVtSB2SWF066KhBLXbMm")
    #consumer_keys[index]
    consumer_secret = ("qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h")
    #consumer_secrets[index]
    username = usernames[index]
    password = passwords[index]
    email = emails[index]
    proxy = proxies[index]

    os.environ['http_proxy'] = proxy 
    os.environ['HTTP_PROXY'] = proxy
    os.environ['https_proxy'] = proxy
    os.environ['HTTPS_PROXY'] = proxy

    oauth1_user_handler = tweepy.OAuth1UserHandler(
        consumer_key, consumer_secret,
        callback="oob"
    )

    urlauth = oauth1_user_handler.get_authorization_url(signin_with_twitter=True)
    print (urlauth)

    driver = webdriver.Chrome(executable_path=CM().install(), options=options)
    #driver = webdriver.Chrome(options=options, executable_path=r"chromedriver.exe")
    actions = ActionChains(driver)
    actions2 = ActionChains(driver)
    actions3 = ActionChains(driver)


    driver.get(urlauth)
    sleep(2)



    # Find the username input field and type the username
    driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[1]/input').click() 
    driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[1]/input').send_keys(username)

    # Find the password input field and type the password
    driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[2]/input').click() 
    driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[2]/input').send_keys(password)

    # click sign in
    driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[2]/input[1]').click() 

    sleep(3)


    # Find the email input field and type the email
    driver.find_element_by_xpath('/html/body/div[2]/div/form/input[8]').click() 
    driver.find_element_by_xpath('/html/body/div[2]/div/form/input[8]').send_keys(email)
    # click submit
    driver.find_element_by_xpath('/html/body/div[2]/div/form/input[9]').click()
    # click 
    driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset/input[1]').click()

    sleep(3)
    copypin = driver.find_element_by_xpath('/html/body/div[2]/div/p/kbd/code').text
    print(copypin)

    verifier = copypin

    access_token, access_token_secret = oauth1_user_handler.get_access_token(
        verifier
    )
    print (access_token, access_token_secret)

    file_1= '/home/user/tweepy/accesstoken.txt'
    file_2= '/home/user/tweepy/accesstokensecret.txt'
    file_3= '/home/user/tweepy/name.txt'    
    try:
        with open(file_1, 'a+') as filehandle:
            filehandle.write('%s\n' % access_token)
    except:
        print('error')
    try:
        with open(file_2, 'a+') as filehandle:
            filehandle.write('%s\n' % access_token_secret)
    except:
        print('error')
    try:
        with open(file_3, 'a+') as filehandle:
            filehandle.write('%s\n' % username)
    except:
        print('error')
    
    sleep(5)
    driver.close() 
  except:
    print (f'failed {username}')


#token = driver.execute_script('location.reload();var i=document.createElement("iframe");document.body.appendChild(i);return i.contentWindow.localStorage.token').strip('"') # Get the token


sleep(5)

print(f'fucking done bitch!')

driver.close() 

