from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
import tweepy
import os
import zipfile
import imaplib
import email
from email.header import decode_header
import webbrowser

proxy_users = (
    "brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-17")
proxy_passes = (
    "vgl6bkabha4b","vgl6bkabha4b","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","r2o4d9d48qcc")
usernames = (
"LindaSu44454921","ShariRo63249685","DoraSco81409863","MildredLaux6","JeanOrt22028681","Janette72478214","Jennife59728812","NormaWa38595540")
passwords = (
    "btnrrmb1908558.","aesbrh781816.","yrmzfoc2930360.","kdimb35606.","zrbl2248.","sfnc1515.","himggnh3832572.","unylrae6889347.")
emails = (
    "zolotollanaiw@outlook.pt","csapikaleesf@outlook.fr","fedidecky1@outlook.jp","roxtonhabibad@outlook.hu","xwayiziar7@outlook.cz","khumonosovv@outlook.cz","keqipiniku8@outlook.cz","opalerayenee@outlook.pt")
consumer_keys = (
    "UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u")
consumer_secrets = (
    "qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS")
proxies = (
    "http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225")

"""
priscillawa2j5r@hotmail.com:hex2Kty28my
mareebrzw@hotmail.com:nx00vO3syz
cletusne26m@hotmail.com:nenvchgjB5q
martinclaarfywh@hotmail.com:lnYfqt27upd
lieselottepiuws@hotmail.com:v51800Sfzb
ardis0fubesa@hotmail.com:zu2bfU1qd7
laqsidhu4n@hotmail.com:cknuUyf7vi2
jamilal723m@hotmail.com:Vfo2o8wl3n
kiygivaquez@hotmail.com:Szs7zu4mn
dulcesus7@hotmail.com:ibI3rslohg4
"""


# account credentials
email = "mareebrzw@hotmail.com"
emailpass = "nx00vO3syz"

imap_server = "imap-mail.outlook.com"

def clean(text):
    # clean text for creating a folder
    return "".join(c if c.isalnum() else "_" for c in text)

    # create an IMAP4 class with SSL 
    imap = imaplib.IMAP4_SSL(imap_server)
    # authenticate
    imap.login(eamil, emailpass)

    status, messages = imap.select("INBOX")
    # number of top emails to fetch
    N = 1
    # total number of emails
    messages = int(messages[0])

    for i in range(1):
        # fetch the email message by ID
        res, msg = imap.fetch(str(i), "(RFC822)")
        for response in msg:
            if isinstance(response, tuple):
                # parse a bytes email into a message object
                msg = email.message_from_bytes(response[1])
                # decode the email subject
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    # if it's a bytes, decode to str
                    subject = subject.decode(encoding)
                # decode email sender
                From, encoding = decode_header(msg.get("From"))[0]
                if isinstance(From, bytes):
                    From = From.decode(encoding)
                print("Subject:", subject)
                print("From:", From)
                # if the email message is multipart
                if msg.is_multipart():
                    # iterate over email parts
                    for part in msg.walk():
                        # extract content type of email
                        content_type = part.get_content_type()
                        content_disposition = str(part.get("Content-Disposition"))
                        try:
                            # get the email body
                            body = part.get_payload(decode=True).decode()
                        except:
                            pass
                        if content_type == "text/plain" and "attachment" not in content_disposition:
                            # print text/plain emails and skip attachments
                            print(body)
                        elif "attachment" in content_disposition:
                            # download attachment
                            filename = part.get_filename()
                            if filename:
                                folder_name = clean(subject)
                                if not os.path.isdir(folder_name):
                                    # make a folder for this email (named after the subject)
                                    os.mkdir(folder_name)
                                filepath = os.path.join(folder_name, filename)
                                # download attachment and save it
                                open(filepath, "wb").write(part.get_payload(decode=True))
                else:
                    # extract content type of email
                    content_type = msg.get_content_type()
                    # get the email body
                    body = msg.get_payload(decode=True).decode()
                    if content_type == "text/plain":
                        # print only text email parts
                        print(body)
                if content_type == "text/html":
                    # if it's HTML, create a new HTML file and open it in browser
                    folder_name = clean(subject)
                    if not os.path.isdir(folder_name):
                        # make a folder for this email (named after the subject)
                        os.mkdir(folder_name)
                    filename = "index.html"
                    filepath = os.path.join(folder_name, filename)
                    # write the file
                    open(filepath, "w").write(body)
                    # open in the default browser
                    webbrowser.open(filepath)
                print("="*100)
    # close the connection and logout
    imap.close()
    imap.logout()


#token = driver.execute_script('location.reload();var i=document.createElement("iframe");document.body.appendChild(i);return i.contentWindow.localStorage.token').strip('"') # Get the token


sleep(5)

print(f'fucking done bitch!')


