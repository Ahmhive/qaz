from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
options = webdriver.ChromeOptions()
import tweepy

usernames: ("LauraBo36207339","DebraLa57295703","CarolWa03288628","Natasha70523383","SusanBu85332905","Shantel54482360","MaryanneGilli16","Matilda17228633","LoreneMadsen16","KellyTh62908744","Deborah94070865","Margare80187781","NormaMc73715163","KathleenPuga12","JudiBro85688623","Barbara94499168","NancyMc76007105","KarinDo93054241","LindaSu44454921","ShariRo63249685","DoraSco81409863","MildredLaux6","JeanOrt22028681","Janette72478214","Jennife59728812","NormaWa38595540","@SharonD61953739","AgnesIv89284678","RosePar46823873","AltheaH82764730","BirdieS15711557","Rebecca17073044","LouiseM89976990","JoannBlain17","ErmaCully8","Barbara05578825","Elizabe49801757","MyrtleSuper16","TinaCar42517756","Barbara06211761","DawnBro80749395","Michell03011449","JohnnieHidalg17","BettyKi63119407","Margare16090624")
passwords: ("xtujn11614.","qsxot11286.","hrghgko6557699.","vtreb17695.","utkqpi731697.","hnizdkr1926082.","sstvi16204.","mfocv09164.","uxel2394.","deitu44311.","cmnlhgw5460790.","nxklhy484236.","tbnl7614.","wlai2424.","jwajav596383.","mhwlzer7563161.","ugrtj99193.","arhk3247.","btnrrmb1908558.","aesbrh781816.","yrmzfoc2930360.","kdimb35606.","zrbl2248.","sfnc1515.","himggnh3832572.","unylrae6889347.","yxdpbc162983.","wife1189.","jyiiti794762.","odiz2437.","tulaveq4136621.","hyvw5757.","fmgtnu241292.","zctdd65186.","btljsre5130108.","mqwt6244.","iaqiqi477115.","dfez1457.","fiaap68266.","zveyns594379.","zfiixe775609.","zslco74815.","tqrxbw183239.","vvujg17472.","tueuvjm0618656.")
emails: ("hromromotu@outlook.pt","mengsaherneyf@outlook.co.th","ceklictrixla@outlook.sg","hlebecfosta2@outlook.com.au","dethosharfaz@outlook.ie","pscmyekik@outlook.kr","woninkpayasaa@outlook.fr","kasnludkai@outlook.dk","thoumakucv@outlook.com.au","sildasiwinan@outlook.com.gr","miudoelisesr@outlook.cl","fwfijoceni7@outlook.com.br","melegnikashg@outlook.es","pfundmogolau@outlook.co.th","gurjerneputea@outlook.hu","skerdaobeydo@outlook.hu","janapbragog@outlook.de","hasahalickq@outlook.at","zolotollanaiw@outlook.pt","csapikaleesf@outlook.fr","fedidecky1@outlook.jp","roxtonhabibad@outlook.hu","xwayiziar7@outlook.cz","khumonosovv@outlook.cz","keqipiniku8@outlook.cz","opalerayenee@outlook.pt","rrengodjordy8@outlook.be","mackanlarsg@outlook.lv","luodesjlayelm@outlook.com.br","kumusnamzove@outlook.dk","tjinoupihlog@outlook.com.au","henerikarba9@outlook.dk","yonjansoruo@outlook.ie","prouajheson7@outlook.dk","mortdastupuo@outlook.lv","ukellafreimc@outlook.de","hfidaseminy@outlook.jp","kipacatamrh@outlook.it","skukanlouvel@outlook.pt","zainurhetson4@outlook.ie","horhebanesb@outlook.co.th","symezmalvav@outlook.sk","chilinyimems@outlook.kr","amaryfoukim@outlook.jp","gingcurguzy@outlook.sk")
consumer_keys = ("Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","Kqxs85C2TLheOV5ysxsrzNmYk","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","UBvqfyVtSB2SWF066KhBLXbMm","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u","EUxsPuLgYLWRSLXOQ5gnDRs7u")
consumer_secrets = ("WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","WwfUDqgA0TrFtCfWuS2nz4ZHDXpEfXeEPYVrOOhGOSs7VePy8L","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","qQCKFBamzNv8pcPPsLhlP3n6s9gjNXs6SyeF2QXqJRZSbBQI4h","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS","rFC9KW57ttm3g0sjCxyNYCBM2HhAytQztPqx3W8xDhCMlQ1wBS")
proxies = ("http://brd-customer-hl_b4776d43-zone-12:j8am0uklfk84@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-12:j8am0uklfk84@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-12:j8am0uklfk84@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-12:j8am0uklfk84@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-12:j8am0uklfk84@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-13:v5u3pnkjwpui@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-13:v5u3pnkjwpui@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-13:v5u3pnkjwpui@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-13:v5u3pnkjwpui@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-13:v5u3pnkjwpui@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-14:w6p505kmf1vh@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-14:w6p505kmf1vh@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-14:w6p505kmf1vh@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-14:w6p505kmf1vh@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-14:w6p505kmf1vh@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-15:vgl6bkabha4b@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-16:n7tbz6e24kho@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-17:r2o4d9d48qcc@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-18:9g8cw1vim7yg@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-18:9g8cw1vim7yg@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-18:9g8cw1vim7yg@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-18:9g8cw1vim7yg@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-18:9g8cw1vim7yg@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-19:mvb3dyjjb1d2@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-19:mvb3dyjjb1d2@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-19:mvb3dyjjb1d2@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-19:mvb3dyjjb1d2@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-19:mvb3dyjjb1d2@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-20:36zir8f8mm5m@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-20:36zir8f8mm5m@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-20:36zir8f8mm5m@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-20:36zir8f8mm5m@zproxy.lum-superproxy.io:22225","http://brd-customer-hl_b4776d43-zone-20:36zir8f8mm5m@zproxy.lum-superproxy.io:22225")



for index in range(1):
  
  os.environ['http_proxy'] = proxy 
  os.environ['HTTP_PROXY'] = proxy
  os.environ['https_proxy'] = proxy
  os.environ['HTTPS_PROXY'] = proxy

  consumer_key = consumer_keys[index]
  consumer_secret = consumer_secret[index]
  username = usernames[index]
  password = passwords[index]
  email = emails[index]
  proxy = proxies[index]


  oauth1_user_handler = tweepy.OAuth1UserHandler(
      consumer_key, consumer_secret,
      callback="oob"
  )

  urlauth = oauth1_user_handler.get_authorization_url(signin_with_twitter=True)
  print (urlauth)

  driver = webdriver.Chrome(executable_path=CM().install(), options=options)
  #driver = webdriver.Chrome(options=options, executable_path=r"chromedriver.exe")
  actions = ActionChains(driver)
  actions2 = ActionChains(driver)
  actions3 = ActionChains(driver)
  driver.get(urlauth)

  sleep(2)

  ### Generate the bith date ###


  # Find the username input field and type the username
  driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[1]/input').click() 
  driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[1]/input').send_keys(username)

  # Find the password input field and type the password
  driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[2]/input').click() 
  driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[2]/input').send_keys(password)

  # click sign in
  driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[2]/input[1]').click() 

  # Find the username input field and type the email
  driver.find_element_by_xpath('/html/body/div[2]/div/form/input[8]').click() 
  driver.find_element_by_xpath('/html/body/div[2]/div/form/fieldset[1]/div[2]/input').send_keys(email)

  # click submit
  driver.find_element_by_xpath('/html/body/div[2]/div/form/input[9]').click()

  copypin = driver.find_element_by_xpath('/html/body/div[2]/div/p/kbd/code').text()


  verifier = copypin
  access_token, access_token_secret = oauth1_user_handler.get_access_token(
      verifier
  )


"""
driver.find_element_by_xpath('/html/body/div[2]/div/form/input[9]').click()
driver.find_element_by_xpath(random.choice(months)).click() # Month
actions.send_keys(Keys.ENTER)

actions.send_keys(day) # Day
actions.send_keys(Keys.ENTER)

actions.send_keys(str(random.choice(year))) # Year
actions.send_keys(Keys.ENTER)

actions.perform()

try:
 driver.find_element_by_xpath('/html/body/div[1]/div[2]/div/div/form/div/div/div[5]/label/input').click() # Accept TOS
except NoSuchElementException:  # Sometimes the checkbox doesnt appear
  pass
driver.find_element_by_xpath('/html/body/div[1]/div[2]/div/div/div/form/div/div/div[5]/button').click()      # Continue
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/div/div/form/div/div/div[4]/div[1]/div[1]/div/div/div/div[1]/div[1]').click.send_keys(monthwords).send_keys(Keys.ENTER)

print('captcha')

input('Press ENTER to get 0Auth token.')  # Waits for user to solve captcha before moving on
"""

#token = driver.execute_script('location.reload();var i=document.createElement("iframe");document.body.appendChild(i);return i.contentWindow.localStorage.token').strip('"') # Get the token


sleep(5)

print(f'Made account:')
print(f'{email}:{password}:{username}:{token}')

sleep(9888888888888888888888888888)
driver.close() 

