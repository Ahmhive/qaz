from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
from random import randint
import tweepy
import os
import zipfile
from imap_tools import MailBox, AND
from anticaptchaofficial.funcaptchaproxyless import *
from urllib.parse import quote
from proxy_checker import ProxyChecker


#proxy_users = ("brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-17")
#proxy_passes = ("vgl6bkabha4b","vgl6bkabha4b","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","r2o4d9d48qcc")
#usernames = ("LindaSu44454921","ShariRo63249685","DoraSco81409863","MildredLaux6","JeanOrt22028681","Janette72478214","Jennife59728812","NormaWa38595540")
#passwords = ("btnrrmb1908558.","aesbrh781816.","yrmzfoc2930360.","kdimb35606.","zrbl2248.","sfnc1515.","himggnh3832572.","unylrae6889347.")
"""
wendybte@hotmail.com:m6rSngbs7m
kimballosc0n@hotmail.com:zj8u8sHoh6
nonawhiten0d7@hotmail.com:m0recBqv1ol
seritalamicals63@hotmail.com:xxr7Yzvg1bm
louraklopp2xp@hotmail.com:s1jkVoxzh4
piercezossy1@hotmail.com:h54khma1sFg
clayaz9mu@hotmail.com:Ifl07dm31mi
lilibethavz7@hotmail.com:pA0cnisx82
tanzimct0pc@hotmail.com:wXu6txqjs7f
tracirhmpt@hotmail.com:xSh5v7mgm
lonnyywoi@hotmail.com:v5xv3m8F1
jonekulpqh@hotmail.com:bz611drs0Ck
esmondsal70m@hotmail.com:n1z97Psurv
ushabedson9z0x@hotmail.com:Bbhdz03q6
kesshivesof@hotmail.com:y4Lsba02ppw
"""
emails = ("","","","","","","","","","","","","","clayaz9mu@hotmail.com","piercezossy1@hotmail.com","louraklopp2xp@hotmail.com","seritalamicals63@hotmail.com","nonawhiten0d7@hotmail.com","kimballosc0n@hotmail.com","wendybte@hotmail.com",)
emailpasses = ()
proxy1 = ("bNLVMHWiRD4ui6N5_session-UwCWhpKq","bNLVMHWiRD4ui6N5_session-Ksolrag7")

"""
for index in range(2,5):
    proxy = proxy1[index]
    checker = ProxyChecker()
    checker.check_proxy(proxy='http://proxy.packetstream.io:31112', user= ("ahmed_e"), password= proxy)
    print (checker.check_proxy.results)
"""

for index in range(2, 10):


    PROXY_HOST = 'zproxy.lum-superproxy.io'  # rotating proxy or host
    PROXY_PORT = 22225 # port
    PROXY_USER = ("brd-customer-hl_b4776d43-zone-residential") # username
    PROXY_PASS = ("bc5o23qziyh7")# password

    manifest_json = """
    {
        "version": "1.0.0",
        "manifest_version": 2,
        "name": "Chrome Proxy",
        "permissions": [
            "proxy",
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version":"22.0.0"
    }
    """

    background_js = """
    var config = {
            mode: "fixed_servers",
            rules: {
            singleProxy: {
                scheme: "http",
                host: "%s",
                port: parseInt(%s)
            },
            bypassList: ["localhost"]
            }
        };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "%s",
                password: "%s"
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)

    
    pluginfile = 'proxy_auth_plugin.zip'

    with zipfile.ZipFile(pluginfile, 'w') as zp:
        zp.writestr("manifest.json", manifest_json)
        zp.writestr("background.js", background_js)


    options = webdriver.ChromeOptions()
    options.add_argument('--headless=chrome')
    options.add_extension(pluginfile)
    options.add_argument('ignore-certificate-errors')
    options.add_argument('--remote-debugging-port=9222')


    username = "ethmhasdaan.eth42813"
    password = "QAwsZXx123"


    email = "kesshivesof@hotmail.com"
    emailpass = "y4Lsba02ppw"

    #proxy = ("http://brd-customer-hl_b4776d43-zone-residential:d2gzikkwg5id@zproxy.lum-superproxy.io:22225")
    nametext = ("anadeasfa sfgdwth")
    


    #os.environ['http_proxy'] = proxy 
    #os.environ['HTTP_PROXY'] = proxy
    #os.environ['https_proxy'] = proxy
    #os.environ['HTTPS_PROXY'] = proxy


    #urlauth = oauth1_user_handler.get_authorization_url(signin_with_twitter=True)
    #print (urlauth)
    
    driver = webdriver.Chrome(executable_path=CM().install(), options=options)
    #driver = webdriver.Chrome(options=options, executable_path=r"chromedriver.exe")
    actions = ActionChains(driver)
    actions2 = ActionChains(driver)
    actions3 = ActionChains(driver)


    #driver.get(urlauth)
    driver.get("https://www.whatismyip.com/")
    #iptext = by.xpath('    /html/body/div[2]/div/div[1]/div/div/main/article/div[1]/section/div/h2[1]/span/a').text
    #print(iptext)
    driver.get("https://twitter.com/signup")
    sleep(4)
    
    # click sign up
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[5]').click()    

    # name 
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[1]/label/div/div[2]/div/input').click() 
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[1]/label/div/div[2]/div/input').send_keys(nametext)

    # click use email
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[3]').click() 

    # email

    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[2]/label/div/div[2]/div/input').click() 
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[2]/label/div/div[2]/div/input').send_keys(email)

    randm= randint(1,11)
    randd= randint(1,28)
    randy= randint(24,44)

    sleep(10)

    #month
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div/div[1]/select').click() 
    sleep(2)
    by.xpath(f'/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div/div[1]/select/option[{randm}]').click() 
    #day
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div/div[2]/select').click() 
    sleep(2)
    by.xpath(f'/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div/div[2]/select/option[{randd}]').click() 
    #year
    by.xpath(f'/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div/div[3]/select').click() 
    sleep(2)
    by.xpath(f'/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div/div[3]/select/option[{randy}]').click() 

    # click next
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div').click() 
    sleep(2)
    # click next
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div').click() 
    sleep(2)
    # click next
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div[2]/div').click() 
    
    # click next
    #by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div[2]/div').click() 
    
    solver = funcaptchaProxyless()
    solver.set_verbose(1)
    solver.set_key("5453d595464aa3b2ca3989cc507688bc")
    #solver.set_website_url("https://iframe.arkoselabs.com/")
    solver.set_website_url("https://twitter.com/")
    solver.set_website_key("2CB16598-CB82-4CF7-B332-5990DB66F3AB")
    #solver.set_proxy_address('44.206.24.6')#88063828106335412.0655053702
    #solver.set_proxy_port(PROXY_PORT)
    #solver.set_proxy_login(PROXY_USER)
    #solver.set_proxy_password(PROXY_PASS)
    #solver.set_user_agent("Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36")

    token = solver.solve_and_return_solution()
    if token != 0:
        print("result token: "+token)
    else:
        print("task finished with error "+solver.error_code)

    
    iframe = driver.find_elements(By.TAG_NAME,'iframe')[0]
    driver.switch_to.frame(iframe)
    iframe = driver.find_elements(By.TAG_NAME,'iframe')[0]
    driver.switch_to.frame(iframe)
    iframe = driver.find_elements(By.TAG_NAME,'iframe')[0]
    driver.switch_to.frame(iframe)
    iframe = driver.find_elements(By.TAG_NAME,'iframe')[0]
    driver.switch_to.frame(iframe)
    # click next
    by.xpath('/html/body/div/div/div[1]/button').click() 
    driver.switch_to.default_content()
    

    newtoken = "{'token': '"+token+"'}"
    print (newtoken)
    #try:
    driver.execute_script('parent.postMessage(JSON.stringify({eventId:"challenge-complete",payload:{sessionToken:'+newtoken+'}}),"*")')
    #except:
    #    donothing= True
    
    
    sleep(5)
    with MailBox('imap-mail.outlook.com').login(email, emailpass) as mailbox:
        for msg in mailbox.fetch():
            try:
                codeend = msg.subject.index(" is your Twitter verification code")
                verifycode = msg.subject[0:codeend]
                print(verifycode)
            except:
                sleep(5)
            try:
                codeend = msg.subject.index(" is your Twitter verification code")
                verifycode = msg.subject[0:codeend]
                print(verifycode)
                #urlstart = msg.html.index("https://developer.twitter.com/en/portal/account/")
                #urlend = msg.html.index("/verify") + 7
                #emailpaste = msg.html
                #verifylink = emailpaste[urlstart:urlend]
                #print(verifylink)
            except:
                donothing = True


    driver.switch_to.default_content()
    
    # verify code
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input').click() 
    sleep(2)
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input').send_keys(verifycode)
    #next
    sleep(2)
    by.xpath('/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div').click() 
    
    #

    # Find the email input field and type the email
    #by.xpath('/html/body/div[2]/div/form/input[8]').click() 
    #by.xpath('/html/body/div[2]/div/form/input[8]').send_keys(email)
    # click submit
    #by.xpath('/html/body/div[2]/div/form/input[9]').click()
    # click 
    #by.xpath('/html/body/div[2]/div/form/fieldset/input[1]').click()

    sleep(100)
    
    
    """
    file_1= '/home/user/tweepy/accesstoken.txt'
    file_2= '/home/user/tweepy/accesstokensecret.txt'
    file_3= '/home/user/tweepy/name.txt'    
    try:
        with open(file_1, 'a+') as filehandle:
            filehandle.write('%s\n' % access_token)
    except:
        print('error')
    try:
        with open(file_2, 'a+') as filehandle:
            filehandle.write('%s\n' % access_token_secret)
    except:
        print('error')
    try:
        with open(file_3, 'a+') as filehandle:
            filehandle.write('%s\n' % username)
    except:
        print('error')

    sleep(5)
    
    #driver.close() 

    

#token = driver.execute_script('location.reload();var i=document.createElement("iframe");document.body.appendChild(i);return i.contentWindow.localStorage.token').strip('"') # Get the token


#sleep(5)

#print(f'fucking done bitch!')

#driver.close() 
"""
