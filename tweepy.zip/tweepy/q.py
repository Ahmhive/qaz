import tweepy
import random
import pickle as pic
import subprocess
import os
import socket,sys
from time import sleep
import pprint
import csv
import secrets
import string
from random import randint

#accounts data
with open('dataacc.csv') as csvfile:
            csvstring = csvfile.read() + '\n'
            lines = csvstring.splitlines()
            reader = csv.reader(lines)
            csvdata = list(reader)

#tweetsdata
with open('jokes.csv') as csvfile2:
            csvstring2 = csvfile2.read() + '\n'
            lines2 = csvstring2.splitlines()
            reader2 = csv.reader(lines2)
            csvdata2 = list(reader2)

a=random.choice(('a','α'))
b=random.choice(('b', 'ხ'))
c=random.choice(('c','ċ'))
d=random.choice(('d','đ'))
e=random.choice(('e','ė'))
f=random.choice(('f','ḟ'))
g=random.choice(('g','ġ'))
h=random.choice(('h','ħ'))
i=random.choice(('i','ì'))
j=random.choice(('j','ĵ'))
k=random.choice(('k','ќ'))
l=random.choice(('l','ℓ'))
m=random.choice(('m','ḿ'))
n=random.choice(('n','ń'))
o=random.choice(('o','ó'))
p=random.choice(('p','ρ'))
q=random.choice(('q','q'))
r=random.choice(('r','ŕ'))
s=random.choice(('s','ś'))
t=random.choice(('t','t'))
u=random.choice(('u','ú'))
v=random.choice(('v','ṽ'))
w=random.choice(('w','ẅ'))
x=random.choice(('x','ᶍ'))
y=random.choice(('y','ẏ'))
z=random.choice(('z','ẑ'))



tweets1= ("are you intrested in helping hivebots nft? they are a robot delivery company raising seed funds through an nft collection","if you are intrested in helping hivebots nft, the robot delivery company raising seed funds through an nft collection","help hivebots nft? a robot delivery company raising seed funds through an nft collection","are you intrested in helping hivebots nft? they are a robot delivery company raising seed funds through an nft collection","hivebots robot delivery company is raising seed funds through an nft collection","hivebots robot delivery company raising seed funds through an nft collection","can you help the hivebots robot delivery company market its nft collection?","hivebots is a robot delivery company raising seed funds through an","tweet a message to @hivebots and tell them you would help their nft collection","hivebots robot delivery company is raising seed funds through an nft collection, would you like to help them?","hivebots nft is a collection of artwork and digital assets for the hivebots robot delivery company","hivebots nft is a robot delivery company raising seed funds through an nft collection","if you are intrested in helping the hivebots nft, robot delivery company raise funds, please retweet this","hivebots robot delivery company needs help marketing its nft collection","are you intrested in helping hivebots nft? they are a robot","hivebots nft, robot delivery company raising seed funds through an nft collection","hivebots nft, robot delivery company raising seed funds","hivebots nft is raising seed funds through an nft collection","hivebots nft is a robot delivery company raising seed funds through an","the hivebots nft collection is available on the etherscan nft explorer.","the hivebots nft collection is a collection of artwork for a robot delivery company raising seed funding","hivebots robot delivery company raising seed funds through an nft collection","a look into the hivebots nft collection","if you are interested in helping hivebots nft, contact them here","hivebots nft is a collection of an unreleased album, an unreleased song, an unreleased comic book, a unique code to","the hivebots robot delivery company is raising seed funds through an nft collection","Let's say you have a list of tweets you want to classify.","hivebots is a robot delivery company raising seed funds through an nft collection","robot delivery company raising seed funds through an nft collection","hivebots is a robot delivery company raising seed funds through an nft collection","hivebots is a robot delivery company raising seed funds through an","the hivebots nft collection is a chance to help a great company raise seed funding","help hivebots nft collectors by spreading the","hivebots nft collection is a collection of nft artwork created by some of the worlds top artists. we need help marketing it","HIVEBOTS is a robot delivery company raising seed funds through an NFT collection.","the hivebots robot delivery company needs help marketing its nft collection","the hivebots robot delivery company needs help marketing its nft collection","hivebots nft: robot delivery company raising seed funds through an nft collection","hivebots nft: robot delivery company raising seed funds","the hivebots robot delivery company needs help marketing its nft collection","are you intrested in helping hivebots nft? they are a robot delivery company raising seed funds through an nft collection","hivebots, a robot delivery company raising seed funds through an nft collection","if you are intrested in helping hivebots nft, the robot delivery company raise seed funds through an nft collection","hivebots robot delivery company needs help marketing its nft collection","the hivebots robot delivery company needs help marketing its nft collection","we have made a nft collection to help the hivebots robot delivery company raise seed funds","the hivebots nft collection is a way to help a robot delivery company raise seed funds","the hivebots robot delivery company is raising seed funds through an nft collection. if you like robots, check it out","the hivebots nft collection is live and has a limited time for investment. check it out","check out the hivebots nft collection and help them out","the hivebots nft collection is a way for people to help a robot","hivebots is a robot delivery company raising seed funds through an nft collection","hivebots robot delivery company raising seed funds through an nft","hivebots nft collection is live. are you intrested in helping them out? they are a robot delivery company raising seed funds through an nft collection","hivebots robot delivery company needs help marketing its nft collection","hivebots robot delivery company is raising seed funds through an nft collection","hivebots nft is raising seed funds through an nft collection","robot delivery company raising seed funds through an nft collection","hivebots nft collection will launch on the 1st of october","if you buy an nft you will get a hivebots robot delivery","the hivebots robot delivery company needs help marketing its nft collection","the hivebots nft collection is for a seed round of funding","hivebots robot delivery company raising seed funds through an nft collection","robot delivery company raising seed funds through an nft collection","the hivebots nft collection is a way for investors to help fund a company building robots to deliver packages","hivebots, the robot delivery company, has a new nft collection to help raise seed funds","if you like robot delivery companies, you should consider helping hivebots nft","robot delivery companies are the future, help hivebots nft","the hivebots robot delivery company needs help marketing its nft collection","hivebots is a robot delivery company that is raising funds via a collection","the hivebots robot delivery company is raising seed funds through an nft collection","hivebots is raising seed funds through an nft collection","the hivebots robot delivery company needs help marketing its nft collection","the hivebots robot delivery company needs help marketing its nft collection","hivebots is a robot delivery company raising seed funds through an nft collection","hivebots nft collection is a way to help a robot","hivebots nft: robot delivery company raising seed funds through an nft collection","hivebots nft: robot delivery company raising seed funds","can you help me promote this nft collection for the hivebots robot delivery company?","this is a nft collection for the hivebots")

tweets2 = ("(do you think this tweet is intresting?","how would you like to be notified?","how would you like to be contacted?","reply if you want to help market this","I want to get all the tweets that have the same text, even if the date is different, and only get","I want to know if you are interested in this","I am asking you if you are interested in this","I am asking if you are","share this tweet to get more followers","are you looking for a new job?","maybe you can help market this","are you","tweet this to your followers","maybe you can help market this","are you intrested in this?","tweet this to your followers","I am intrested in this.","You can also try to use some sort of tagging system like hashtags or mentions, or just use keywords in the body","is this tweet worth your attention?","do you like this?","would you like to see more of this?","can you","would you like to learn more about this?","do you like this tweet?","Once you have done this, you can create a message that is tail","can you help me out?","If you want to know more, I suggest you read this post.","i would be happy to answer your questions","thanks in advance","best regards","ndo you know someone who is?","want to help spread the word?","maybe you can help market this","are you intrested in this?","maybe you can help market this","are you intrested","can you help me with this?","i need your help with this","would you help me with this?","help me with","help me spread the word?","can you retweet this?","this is important for me","thank you for your support","do you like this?","do you like this?","do you think this is cool","you can help us here","maybe you can help us here","maybe you can help market this","are you intrested in this?","maybe you can help market this","are you intrested","click to tweet about","we need your help to promote this!","would you like to help promote this?","would you like to help promote this?","we need more","we are looking for more","we need more people","we need more help","we need more volunteers","if you have an account on twitter, please follow us","if you want to share this, please use this link","if you have any","tell a friend","are you intrested in this?","do you want to be in the know about this?","do you want to know about this?")

tweetids=(123,1231,12313)
tweetnum=0
#tweetnum=pic.load(open('/home/user/tweepy/t.txt','rb'))

print(tweetnum,"start")
file_name= '/home/user/tweepy/number.txt'
try:
    with open(file_name, 'a+') as filehandle:
        filehandle.write('%s\n' % tweetnum)
except:
    print('error')

for index in range(35, 200):

    try:
        username = csvdata[index][2]
        password = csvdata[index][3]
        email = csvdata[index][4]
        emailpass = csvdata[index][5]
        access_token = csvdata[index][6]
        access_token_secret = csvdata[index][7]
        consumer_key = csvdata[index][8]
        consumer_secret = csvdata[index][9]
        joke1 = csvdata2[randint(1,200000)][1]
        #joke2 = csvdata2[randint(1,200000)][1]

        #try:

        #consumer_key = ("BCcsklCjIRHal0VMmxdcLkSdP")
        #consumer_secret = ("3GC3PucZjWG4XIYLWNlWcvMMe3rvF8HhesVx0noQhvzuNGmy1J")
        #access_token = ("1594396919018700801-I6Qhakd7xVrjLbDCF9JKxw7pTT5jw9")
        #access_token_secret = ("uOxPlluTaYzybpjZQBhDlQwFpUoiEBv8bXGc36l15fbvk")

        proxy = ("http://brd-customer-hl_b4776d43-zone-b1:sgyem2ztpbsp@zproxy.lum-superproxy.io:22225")
        #proxy = "http://ahmed_e:bNLVMHWiRD4ui6N5@proxy.packetstream.io:31111"
        #proxy = ("http://ahmed_e:bNLVMHWiRD4ui6N5@proxy.packetstream.io:31111")

        os.environ['http_proxy'] = proxy 
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy


        """
        env_var = os.environ
        
        # Print the list of user's
        # environment variables
        print("User's Environment variable:")
        pprint.pprint(dict(env_var), width = 1)
        """

        tweet1= random.choice(tweets1)
        tweet2= random.choice(tweets2)
        #tweet= f"{tweet1}{tweet2} @hivebots_ "
        tweet= f"{joke1}\n{h}{i}{v}{e} {i}{s} {a}{n} {a}{u}{t}{o}{n}{o}{m}{o}{u}{s} {d}{e}{l}{i}{v}{e}{r}{y} {r}{o}{b}{o}{t} {s}{t}{a}{r}{t}{u}{p}\n{r}{a}{i}{s}{i}{n}{g} {f}{u}{n}{d}{s} {b}{y} {n}{f}{t} {c}{o}{l}{l}{e}{c}{t}{i}{o}{n} {i}{n}{s}{t}{e}{a}{d} {o}{f} {v}{e}{n}{t}{u}{r}{e} {c}{a}{p}{i}{t}{a}{l}\n{p}{o}{k}{e}{m}{o}{n} {g}{o} {l}{i}{k}{e} {g}{a}{m}{e} {c}{a}{l}{l}{e}{d} {h}{i}{v}{e}{b}{o}{t}{s} {r}{o}{a}{m}\n{g}{o} {t}{o} {h}{i}{v}{e}{b}{o}{t}{s} . {x}{y}{z}\n"
        #reply = tweetids[tweetnum]

        client = tweepy.Client(
            consumer_key=consumer_key, consumer_secret=consumer_secret,
            access_token=access_token, access_token_secret=access_token_secret
        )

        response = client.create_tweet(
            #in_reply_to_tweet_id= reply,
            text= tweet,
            #text= "test α	ხ	ċ	đ	ė"
        )
        
        tweetnum = tweetnum + 1
        print(tweetnum)
        #p.dump(tweetnum,open('/home/user/tweepy/t.txt','wb'))
        tweeturl= (f"http://twitter.com/user/status/{response.data['id']}")
        tweetid=response.data['id']
        #except:
            #print(access_token)
        file_1= "/home/user/tweepy/tweets.txt"
        try:
            with open(file_1, 'a+') as filehandle:
                filehandle.write('%s:%s:%s\n' % (username, tweetid, tweeturl)) # Hello john, my name is mike".
        except:
            print('error txt file') 
    except:
        print(f'failed {username}') 
    
with open(file_1, 'a+') as filehandle:
    filehandle.write('--------------') # Hello john, my name is mike".


pic.dump(tweetnum,open('/home/user/tweepy/t.txt','wb'))
print("done,waiting")
#print(f"https://twitter.com/user/status/{response.data['id']}")


