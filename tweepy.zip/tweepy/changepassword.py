from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
from random import randint
import tweepy
import os
import zipfile
from imap_tools import MailBox, AND
from anticaptchaofficial.funcaptchaproxyless import *
from urllib.parse import quote
import csv
import secrets
import string
from threading import Thread
import multiprocessing
import time




def makeacc(accstart,accend):
    for index in range(accstart,accend):
        try:
            with open('dataacc.csv') as csvfile:
                csvstring = csvfile.read() + '\n'
                lines = csvstring.splitlines()
                reader = csv.reader(lines)
                csvdata = list(reader)
                print (csvdata[index])
                #proxyuser = csvdata[index][0]
                #proxypass = csvdata[index][1]
                username = csvdata[index][2]
                password = csvdata[index][3]
                email = csvdata[index][4]
                emailpass = csvdata[index][5]
                access_token = csvdata[index][6]
                access_token_secret = csvdata[index][7]
                consumer_key = csvdata[index][8]
                consumer_secret = csvdata[index][9]

            print(index)
            alphabet = string.ascii_letters + string.digits
            newpass = ''.join(secrets.choice(alphabet) for i in range(9))
            

            #username = ("Stephan12839164")
            #password = ("gkaos59381.")
            #email = ("alizikeniaam@hotmail.com")
            #emailpass = ("G78G8O08")
            #proxy = ("http://brd-customer-hl_b4776d43-zone-2:d2gzikkwg5id@zproxy.lum-superproxy.io:22225")

            #os.environ['http_proxy'] = proxy 
            #os.environ['HTTP_PROXY'] = proxy
            #os.environ['https_proxy'] = proxy
            #os.environ['HTTPS_PROXY'] = proxy

            PROXY_HOST = 'zproxy.lum-superproxy.io'  # rotating proxy or host
            PROXY_PORT = 22225 # port
            PROXY_USER = "brd-customer-hl_b4776d43-zone-b1" # username
            PROXY_PASS = "sgyem2ztpbsp" # password


            manifest_json = """
            {
                "version": "1.0.0",
                "manifest_version": 2,
                "name": "Chrome Proxy",
                "permissions": [
                    "proxy",
                    "tabs",
                    "unlimitedStorage",
                    "storage",
                    "<all_urls>",
                    "webRequest",
                    "webRequestBlocking"
                ],
                "background": {
                    "scripts": ["background.js"]
                },
                "minimum_chrome_version":"22.0.0"
            }
            """

            background_js = """
            var config = {
                    mode: "fixed_servers",
                    rules: {
                    singleProxy: {
                        scheme: "http",
                        host: "%s",
                        port: parseInt(%s)
                    },
                    bypassList: ["localhost"]
                    }
                };

            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "%s",
                        password: "%s"
                    }
                };
            }

            chrome.webRequest.onAuthRequired.addListener(
                        callbackFn,
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)


            pluginfile = 'proxy_auth_plugin.zip'

            with zipfile.ZipFile(pluginfile, 'w') as zp:
                zp.writestr("manifest.json", manifest_json)
                zp.writestr("background.js", background_js)


            options = webdriver.ChromeOptions()
            options.add_argument('--headless=chrome')
            options.add_extension(pluginfile)
            options.add_argument('--window-size=1920,1200')  
            options.add_argument('--ignore-certificate-errors')  
            #urlauth = oauth1_user_handler.get_authorization_url(signin_with_twitter=True)
            #print (urlauth)
            
            driver = webdriver.Chrome(executable_path=CM().install(), options=options)
            #driver = webdriver.Chrome(options=options, executable_path=r"chromedriver.exe")
            actions = ActionChains(driver)
            actions2 = ActionChains(driver)
            actions3 = ActionChains(driver)


            #driver.get(urlauth)
            #driver.get("https://www.whatismyip.com/")
            #iptext = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '    /html/body/div[2]/div/div[1]/div/div/main/article/div[1]/section/div/h2[1]/span/a'))).text
            #print(iptext)

            driver.get("https://twitter.com/login")
            sleep(5)
            # username 
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[5]/label/div/div[2]/div/input'))).click() 
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[5]/label/div/div[2]/div/input'))).send_keys(username)
            sleep(2)
            # click next
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[6]/div'))).click() 
            sleep(3)
            # pass
            sleep(2)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[3]/div/label/div/div[2]/div[1]/input'))).click() 
            sleep(2)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[3]/div/label/div/div[2]/div[1]/input'))).send_keys(password)
            sleep(2)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div[1]/div/div/div/div'))).click() 
            sleep(5)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input'))).click() 
            sleep(2)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input'))).send_keys(email)
            sleep(5)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div/div'))).click() 

            sleep(5)
            driver.get("https://twitter.com/settings/password")
            sleep(5)
            #oldpass

            #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/div[2]/div[1]/div[1]/label/div/div[2]/div/input'))).click() 
            #WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[1]/label/div/div[2]/div/input'))).send_keys(password)    
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[1]/label/div/div[2]/div/input'))).click() 
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[1]/label/div/div[2]/div/input'))).send_keys(password)
            sleep(2)
            #newpass
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[3]/label/div/div[2]/div/input'))).click() 
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[3]/label/div/div[2]/div/input'))).send_keys(newpass)
            sleep(2)
            #confirm newpass
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[4]/label/div/div[2]/div/input'))).click() 
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[1]/div[4]/label/div/div[2]/div/input'))).send_keys(newpass)
            
            sleep(2)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/section[2]/div[2]/div[3]/div/div/span/span'))).click() 
            sleep(5)

            oauth1_user_handler = tweepy.OAuth1UserHandler(
                consumer_key, consumer_secret,
                callback="oob"
            )

            urlauth = oauth1_user_handler.get_authorization_url(signin_with_twitter=True)
            print (urlauth)


            sleep(5)
            driver.get(urlauth)
            sleep(5)

            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div/form/fieldset/input[1]'))).click() 
            sleep(5)
            copypin = WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div/p/kbd/code'))).text
            print(copypin)

            verifier = copypin

            access_token, access_token_secret = oauth1_user_handler.get_access_token(
                verifier
            )
            print (access_token, access_token_secret)

            file_1= '/home/user/tweepy/accounts.txt'
            
            try:
                with open(file_1, 'a+') as filehandle:
                    filehandle.write('%s:%s:%s:%s:%s:%s:%s:%s\n' % (username, newpass, email, emailpass, access_token, access_token_secret, consumer_key, consumer_secret)) # Hello john, my name is mike".
            except:
                print('error') 
            
            sleep(5)
            driver.close() 
            """
            except:
                print (f'failed {username}')
                sleep(5)
            """
        except:
            print(f'failed {username}')

"""
if __name__ == '__main__':
  
    # multiprocessing pool object
    pool = multiprocessing.Pool()
  
    # pool object with number of element
    pool = multiprocessing.Pool(processes=2)
  
    # input list
    inputs = [[201,300],[301,400]]
  
    # map the function to the list and pass
    # function and input list as arguments
    outputs = pool.map(makeacc, inputs)
  
    # Print input list
    print("Input: {}".format(inputs))
  
    # Print output list
    print("Output: {}".format(outputs))

"""

#makeacc(201,300)
#makeacc(301,400)
#makeacc(401,500)
#makeacc(501,600)
#makeacc(601,700)

#makeacc(701,800)
#makeacc(801,900)
#makeacc(901,1000)
#makeacc(1001,1100)
makeacc(1101,1200)

#makeacc(1201,1300)
#makeacc(1301,1400)
#makeacc(1401,1500)
#makeacc(1501,1600)
#makeacc(1601,1700)
#makeacc(1701,1800)





#token = driver.execute_script('location.reload();var i=document.createElement("iframe");document.body.appendChild(i);return i.contentWindow.localStorage.token'))).strip('"') # Get the token


sleep(5)

print(f'fucking done bitch!')

driver.close() 
