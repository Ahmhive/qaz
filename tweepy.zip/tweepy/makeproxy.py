from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC  
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
from random import randint
import tweepy
import os
import zipfile
from imap_tools import MailBox, AND
from anticaptchaofficial.funcaptchaproxyless import *
from urllib.parse import quote


#proxy_users = ("brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-15","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-16","brd-customer-hl_b4776d43-zone-17")
#proxy_passes = ("vgl6bkabha4b","vgl6bkabha4b","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","n7tbz6e24kho","r2o4d9d48qcc")
#usernames = ("LindaSu44454921","ShariRo63249685","DoraSco81409863","MildredLaux6","JeanOrt22028681","Janette72478214","Jennife59728812","NormaWa38595540")
#passwords = ("btnrrmb1908558.","aesbrh781816.","yrmzfoc2930360.","kdimb35606.","zrbl2248.","sfnc1515.","himggnh3832572.","unylrae6889347.")

emails = ("priscillawa2j5r@hotmail.com","mareebrzw@hotmail.com","cletusne26m@hotmail.com","martinclaarfywh@hotmail.com","lieselottepiuws@hotmail.com","ardis0fubesa@hotmail.com","laqsidhu4n@hotmail.com","jamilal723m@hotmail.com","kiygivaquez@hotmail.com","dulcesus7@hotmail.com")
emailpasses = ("hex2Kty28my","nx00vO3syz","nenvchgjB5q","lnYfqt27upd","v51800Sfzb","zu2bfU1qd7","cknuUyf7vi2","Vfo2o8wl3n","Szs7zu4mn","ibI3rslohg4")


options = webdriver.ChromeOptions()

username = ("admin@hivear.co.uk")
password = ("jTDsrS$5h19D")

driver = webdriver.Chrome(executable_path=CM().install(), options=options)
actions = ActionChains(driver)
actions.send_keys('united states')
actions.send_keys(Keys.ENTER)  
actions1 = ActionChains(driver)
actions1.send_keys('twitter.com')
actions1.send_keys(Keys.ENTER)
actions3 = ActionChains(driver)
domain = ("twitter.com")
country = ("united states")

driver.get("https://brightdata.com/cp/zones")

sleep(15)
# username
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[2]/div/div/div[2]/form/div[2]/div/input').click() 
sleep(2)
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[2]/div/div/div[2]/form/div[2]/div/input').send_keys(username)
# password
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[2]/div/div/div[2]/form/div[3]/div[1]/input').click() 
sleep(2)
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[2]/div/div/div[2]/form/div[3]/div[1]/input').send_keys(password)
# click login
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div[2]/div/div/div[2]/form/div[4]/button').click() 


for index in range(100):

    sleep(2)
    # click sign up
    driver.get("https://brightdata.com/cp/zones/new")
    #1005 upitme
    sleep(5)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[4]/div[2]/div/button').click()  
    sleep(2)  
    #dedicated
    driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[3]/div[2]/div[3]/div[1]/input').click()
    sleep(2)    
    #add country
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")

    sleep(2)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[6]/div[2]/div[2]/button/div[1]').click() 
    sleep(2)
    actions.send_keys('united states')
    actions.send_keys(Keys.ENTER)    
    actions.perform()
    sleep(2) 
    driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[7]/div[3]/div[2]').click() 
    sleep(2)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[7]/div[3]/div[2]').click() 
    sleep(2)
    actions1.perform()
    #driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[7]/div[3]').click()    
    #driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[7]/div[3]').send_keys("twitter.com")

    #driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[1]/div/div[6]/div[2]/div[1]').send_keys(keys.ENTER)
    sleep(2)
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
    sleep(2)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[2]/section[2]/div/div[1]/div/div[2]/button').click()  
    sleep(3)  
    driver.find_element_by_xpath('/html/body/div[9]/div[2]/div/div/div[3]/button[2]').click()
    sleep(10)
    

